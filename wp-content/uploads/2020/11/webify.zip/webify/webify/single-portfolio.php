<?php
/**
 * Portfolio Single Page
 *
 * @package webify
 * @since 1.0
 *
 */
get_header(); 
get_template_part('theme/inc/portfolio/single/default');
get_footer();

