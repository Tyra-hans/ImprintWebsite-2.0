<?php
/**
 * Theme Function File
 *
 * @package webify
 * @since 1.0
*/
require get_theme_file_path('admin/init.php');
require get_theme_file_path('theme/init.php');
if (!isset($content_width)) $content_width = 1140;

