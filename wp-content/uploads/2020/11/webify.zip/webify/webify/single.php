<?php
/**
 * Blog Single file
 *
 * @package webify
 * @since 1.0
 */
get_header();
webify_blog_single_style('default');
get_footer();
