<?php
/**
 * Index Page
 *
 * @package webify
 * @since 1.0
 */
get_template_part('theme/inc/blog/loop');

