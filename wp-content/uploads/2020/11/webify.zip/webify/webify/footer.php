<?php
/**
 * Footer file
 *
 * @package webify
 * @since 1.0
 */
?>
<?php webify_footer_style(webify_get_opt('footer-style')); ?>
<?php webify_scroll_top(); ?>
<?php webify_video_popup(); ?>
<?php wp_footer(); ?>
</body>
</html>
